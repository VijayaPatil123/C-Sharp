﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignment
{
    class StrutureStudent
    {
        //int RollNo = 1;
        //string Name = "Vijaya";
        //string Gender = "Female";
        //long MobileNo = 0123456789;

        static void Main()
        {
            Console.WriteLine("====StudentDetails Using Structure:====");

            StudentDetails student = new StudentDetails(1,"Vijaya","Female",123456789);
           Console.WriteLine( student.ShowDetails());
            Console.ReadLine();

        }
    }
    struct StudentDetails
    {
        int RollNo;
        string Name;
        string Gender;
        long MobileNo;

        public StudentDetails(int RollNo, string Name, string Gender, long MobileNo)
        {
            this.RollNo = RollNo;
            this.Name = Name;
            this.Gender = Gender;
            this.MobileNo = MobileNo;
        }

        public string ShowDetails()
        {
          return  string.Format(" \n RollNo={0}\n Name={1}\n Gender={2}\n MobileNo={3}\n", RollNo, Name, Gender, MobileNo);
        }
    }
}
