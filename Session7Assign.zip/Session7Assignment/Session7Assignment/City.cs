﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignment
{
    class EnumCity
    { 
    enum City
    {
         Solapur=060,  Pune=040,Mumbai=050,Delhi=030
    }
        
    static void Main()
    {

            Console.WriteLine("====MAINTAIN CITY NAMES AND RESPECTIVE STD CODES====\n\n");

            foreach (string name in Enum.GetNames(typeof(City)))
            {
                Console.Write("THE CITY NAME IS:");
                Console.WriteLine(name);
            }


            foreach (int STDCode in Enum.GetValues(typeof(City)))
            {
                Console.Write("THE  STD CODE OF THE RESPECTIVE CITY IS:. ");
                Console.WriteLine(STDCode);
            }
            Console.ReadLine();
        }
    }
}
