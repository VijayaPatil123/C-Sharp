﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{

    class Program
    {
        /// <summary>
        /// Develop a program to decide whether person is major or minor using if-else 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Age of person to check major or minor :");

            int Age = Convert.ToInt32(Console.ReadLine());
            if (Age <= 18)
            {
                Console.WriteLine("Person is Minor");
            }
            else
            {
                Console.WriteLine("Person is major");

            }
            Console.ReadLine();
        }
    }
}
