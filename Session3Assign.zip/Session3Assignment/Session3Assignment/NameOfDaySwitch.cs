﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class NameOfDaySwitch
    {
        /// <summary>
        /// Develop a program to display name of the day from taking input 1-7 using switch
        /// </summary>
        static void Main()
        {
            
            Console.WriteLine("Enter number Between 1 to 7\n\n");

            int number = Convert.ToInt32(Console.ReadLine());

            switch (number)
            {
                case 1:  Console.WriteLine("SUNDAY");
                    break;
                case 2:  Console.WriteLine("MONDAY");
                    break;
                case 3:Console.WriteLine("TUESDAY");
                    break;
                case 4: Console.WriteLine("WENSDAY");
                    break;
                case 5:Console.WriteLine("THURSDAY");
                    break;
                case 6:
                    Console.WriteLine("FRIDAY");
                    break;
                case 7:
                    Console.WriteLine("SATURDAY");
                    break;
                default:Console.WriteLine("Invalid Name of the Day");
                    break;

                   

            }
            Console.ReadLine();
        }
    }
}
