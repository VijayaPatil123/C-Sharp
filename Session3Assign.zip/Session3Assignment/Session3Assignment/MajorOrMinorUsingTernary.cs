﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class MajorOrMinorUsingTernary
    {/// <summary>
    /// Develop a Program to decide whether person is major or minor person using Ternary operator
    /// </summary>
        static void Main()
        {
            Console.WriteLine("ENTER THE AGE OF PERSON TO CHECK MAJOR OR MINOR:\n\n");

            int age = Convert.ToInt32(Console.ReadLine());
            string result = age <18 ? "Person is Minor" : "Person is Major";
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
