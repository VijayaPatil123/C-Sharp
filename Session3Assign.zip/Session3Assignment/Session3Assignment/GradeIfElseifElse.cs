﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class GradeIfElseifElse
    {
        /// <summary>
        /// Develope a Program  to Decide according to Percentage using if-else if-else
        /// </summary>
        static void Main()
        {
            Console.WriteLine("==== Deside Grade According to Percentage using If-else If-else====\n\n");

            Console.WriteLine("Enter Percentage  to check Grade:");
            int Percentage = Convert.ToInt32(Console.ReadLine());

            if (Percentage >= 75)
            {
                Console.WriteLine("Grade:A");
            }
            else if (Percentage >= 60 && Percentage < 75)
            {
                Console.WriteLine("Grade:B");
            }
            else if (Percentage >= 40 && Percentage < 60)

            {
                Console.WriteLine("Grade:C");
            }
            else
            {
                Console.WriteLine("Grade:D");
            }

            Console.ReadLine();
        }
    }
}
