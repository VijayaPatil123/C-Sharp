﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class FactorialUsingFunction
    {  
        //Factorial Of given number using function
        static void Main(string[] args)
        {
            Console.WriteLine("*******FACTORIAL OF GIVEN NUMBER USING FUNCTION*****\n\n");

            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            long fact = FactorialCalculate(n);
            Console.WriteLine("Factorial of {0} is:{1}", n, fact);
            Console.ReadLine();

        }
    

    public static int FactorialCalculate(int n)
    {
        if (n == 0)
        {
            return 1;
        }
        return n * FactorialCalculate(n - 1);
    }
    }
    
}
