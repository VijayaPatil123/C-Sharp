﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class jaggedarrayusingfunction
    {
        //SEARCH ELEMENT OF JAGGED ARRAY  USING FUNCTION
        public void seach(int[][]array1,int elem)
        {
            int search = 0;

            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in array1[i])
                {
                    if (elem == temp)
                    {
                        search = 1;
                        break;
                    }
                }
            }
            if (search == 1)
            {
                Console.WriteLine("{0} Number Found", elem);
            }
            else
            {
                Console.WriteLine("Number not Found");
            }
        }
        static void Main()
        {
            Console.WriteLine("******SEARCH ELEMENT USING JAGGED ARRAY*******\n\n");

            int[][] array1 = new int[2][];
            array1[0] = new int[] { 10, 20, 30, 40 };
            array1[1] = new int[] { 50, 60 };
            Console.WriteLine("Array:");
            

            for (int a = 0; a < 2; a++)
            {
                foreach (int temp in array1[a])
                {
                    Console.WriteLine(temp);
                }
                Console.WriteLine();
            }
            Console.WriteLine("Enter the Elements:");
            int elem = Convert.ToInt32(Console.ReadLine());
            jaggedarrayusingfunction j = new jaggedarrayusingfunction();
            j.seach(array1, elem);
            Console.ReadLine();


        }
    }        
}
