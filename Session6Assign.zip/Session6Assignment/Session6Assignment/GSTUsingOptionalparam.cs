﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class GSTUsingOptionalparam
    {/// <summary>
    /// Program to Calculate GST Using Optional Parameter
    /// </summary>
        static void Main()
        {
            Console.WriteLine("*****CALCULATE GST USING OPTIONAL PARAMETER*****\n\n");

            GSTUsingOptionalparam gstoptional = new GSTUsingOptionalparam();
            Console.WriteLine("Enter The amount:");
            int amount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Time:");
            int time = Convert.ToInt32(Console.ReadLine());
                
            Console.WriteLine("GST is: {0}",gstoptional.GST(100));
            Console.ReadLine();

        }
        public int GST(int amount, int gst = 2)
        {
            int temp = (amount * gst / 100);
            temp = temp + amount;
            return temp;
        }
    }
}
