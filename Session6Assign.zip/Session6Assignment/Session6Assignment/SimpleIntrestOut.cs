﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class SimpleIntrestOut
    {
        //CALCULATE SIMPLE INTREST AND AMOUNT USING OUT PARAMETER
        static void Main()
        {
            Console.WriteLine("******SIMPLE INTREST AND AMOUNT USING OUT PARAMETER*******\n\n");

            SimpleIntrestOut SIout = new SimpleIntrestOut();
            Console.WriteLine("Enter Amount:");
            int amount = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Time:");
            int time = Convert.ToInt32(Console.ReadLine());
            double a;

            double intrest = SIout.CalculateSI(amount, time, out a);
            Console.WriteLine(amount);
            Console.WriteLine(intrest);
            Console.ReadLine();

            }

        public double CalculateSI(int amount,int time, out double x)
        {
            int Rate = 14;
            double SI = (amount*time*Rate)/100;
            double temp = (amount * time) + SI;
            x = temp;
            return SI;
        }
    }
}
