﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class SimpleIntrestUsingFunction
    { 
        //CALCULATE SIMPLE INTREST USING FUNCTION
        public void CalSimpleIntrest( double P,double R,int T )
        {
            
           
             double  SI = P * R * T / 100;
            Console.WriteLine("Simple Intrest is{0}:", SI);
            Console.ReadLine();

        }
        static void Main()
        {
            Console.WriteLine("*****SIMPLE INTREST USING FUNCTION******\n\n");

            SimpleIntrestUsingFunction simple = new SimpleIntrestUsingFunction();
            Console.WriteLine("Enter the Amount:");
          double  P = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Rate:");
           double R = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Time:");
          int  T = Convert.ToInt32(Console.ReadLine());
            simple.CalSimpleIntrest(P,R,T);
            Console.ReadLine();
         }
    }
}
