﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay1
{
    class ChartoIntAndviceversa
    {
        static void Main()
        {//type cast

            Console.WriteLine("====Conversion of Char to int and vice versa====\n\n");
            Console.WriteLine("Enter Character to Convert into ASCII:");
            Char v = Convert.ToChar(Console.ReadLine());

            int z = (int)v;
            Console.WriteLine(z);


            Console.WriteLine("Enter ASCII to Convert into Character:");
            int b = Convert.ToInt32(Console.ReadLine());

            Char ch = (char)b;
            Console.WriteLine(ch);
            Console.ReadLine();

        }
    }
}
