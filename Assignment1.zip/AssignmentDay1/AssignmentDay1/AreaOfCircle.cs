﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay1
{
    class AreaOfCircle
    {
        /// <summary>
        /// Calculate Area Of Circle
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            
            Console.WriteLine("=====Calculate The Area Of Circle=====\n\n");
            const double PI = 3.14;
            Console.WriteLine("Enter the Radius:");
            int rad =Convert.ToInt32( Console.ReadLine());
            double AOC = rad * rad * PI;
            Console.WriteLine("Area of circle  {0}",AOC);
            Console.ReadLine();
        }
    }
}
