﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay1
{
    class DollertoRupees
    {
        static void Main()
        {
            Console.WriteLine("====Conversion of Doller to Rupee and vice versa====\n\n");

            Console.WriteLine("Enter Doller:");
            int doller = Convert.ToInt32(Console.ReadLine());
            double Rupee = doller * 71.06;
            Console.WriteLine("Doller in Rupee"+Rupee);

            int Rupee1 = 100;
            double doller1 = Rupee1 / 71.06;
            Console.WriteLine("Rupees in Doller"+doller1);

            Console.ReadLine();
        }
    }
}
