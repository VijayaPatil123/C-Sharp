﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class SumOfArrayElement
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******SUM OF EACH ELEMENT IN THE ARRAY*****\n\n");

            Console.WriteLine();
            int[] a = new int[5];
            int i, n, sum = 0;

            Console.WriteLine("Enter the number of elements to store in array:\n\n");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Input elements in the array:");
            for (i = 0; i < n; i++)
            {
                Console.Write( i);
                a[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (i = 0; i < n; i++)
            {
                sum += a[i];
            }
            Console.WriteLine("Sum of all elements is {0}", sum);
            Console.ReadLine();
        }
    }
}
