﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class SearchElementusingjaggedarray
    {
        static void Main()
        {
            Console.WriteLine("====SEARCH THE ELEMENT USING JAGGED ARRAY====\n\n");

            int[][] array1 = new int[2][];
            array1[0] = new int[] { 20, 30, 50, 40 };
            array1[1] = new int[] { 60, 80 };
            Console.WriteLine("Array:");
           

            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in array1[i])
                {
                    Console.Write(" {0}",temp);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Enter the Elements from Array:");
            int Number = Convert.ToInt32(Console.ReadLine());
            int search = 0;

            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in array1[i])
                {
                    if (Number == temp)
                    {
                        search = 1;
                        break;
                    }
                }
            }
            if (search == 1)
            {
                Console.WriteLine("{0} Number Found", Number);
            }
            else
            {
                Console.WriteLine("Number not Found");
            }
            Console.ReadLine();


        }
    }
}
