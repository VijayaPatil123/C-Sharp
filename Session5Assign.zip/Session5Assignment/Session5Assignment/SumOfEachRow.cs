﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class SumOfEachRow
    {
        
        static void Main()
        {
            Console.WriteLine("****SUM OF EACH ROW IN THE ARRAY*****\n\n");

            int[,] a = { { 10, 40, 50 }, { 60, 20, 70 }, { 80, 90, 30 } };

            for (int i = 0; i <= 2; i++)
            {
                int sum = 0;
                for (int j = 0; j <= 2; j++)
                {
                    sum = sum + a[i, j];
                }
                Console.WriteLine("Sum Of Row{0} ",  sum);
               // Console.WriteLine(sum);
            }
           
            Console.ReadLine();

        }
    }
}
