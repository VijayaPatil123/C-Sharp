﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionPositiveOrNegative
{

    public static class ExtensionPositiveOrNegative
    {
       
        public static void IsPositiveOrNegative(this int num, int value)
        {
            if (num > 0)
            {
                Console.WriteLine("Number is Positive...");
            }
            else
            {
                Console.WriteLine("Number is Negative....");
            }
        }

        class TestExtension
        {
            static void Main()
            {

                Console.WriteLine("*****IDENTIFY POSITIVE OR NEGATIVE NUMBER USING EXTENSION METHOD******\n\n");
                int i = 10;
                i.IsPositiveOrNegative(20);
                Console.ReadLine();
            }


        }
    }
}
