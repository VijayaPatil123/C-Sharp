﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST1;

namespace GSTWithConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******GST WITH CONSOLE******\n\n");
            GSTCAL cal = new GSTCAL(12,15000);
            Console.WriteLine(cal.CalculateGST());
            Console.ReadLine();
            
        }
    }
}
