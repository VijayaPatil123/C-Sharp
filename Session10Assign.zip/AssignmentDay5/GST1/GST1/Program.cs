﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GST1
{
  public  class GSTCAL
    {
        double gstper;
        double amount;

        public GSTCAL(double gstper, double amount)
        {
            this.gstper = gstper;
            this.amount = amount;
        }

        public string CalculateGST()
        {
            gstper = 0.05;
           double temp = (amount * gstper);
            amount = amount + temp;
            return $"GST of amount is{temp} and the amount is {amount}";
        }
    }
}
