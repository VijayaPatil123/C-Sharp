﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignments
{
    class OddNumUsingDoWhile
    {
        /// <summary>
        /// Program to display odd number between 1 to 50 using Do While Loop
        /// </summary>
        static void Main()
        {
            Console.WriteLine("==== Odd Number Between 1 to 50 using Do   While====\n");

            int i = 1;
            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(" {0} ",i);
                    
                }
                i++;

            }
            while (i <= 50);
            Console.ReadLine();
        }
    }
}
