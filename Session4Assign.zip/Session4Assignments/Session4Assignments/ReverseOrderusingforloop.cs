﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignments
{
    class ReverseOrderusingforloop
    {/// <summary>
    /// Program to display number in reverse order from 50 to 1 using for loop
    /// </summary>
    /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("=====50 to 1 reverse Order using for loop=====\n");

            for (int a = 50; a >=1; a--)
            {
                Console.WriteLine(" {0} ",a);
            }
            Console.ReadLine();
        }
    }
}
