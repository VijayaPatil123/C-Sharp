﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignments
{
    class Tableusingforloop
    {
        //Print The  Table Of given Number Using For Loop
        static void Main()
        {
            Console.WriteLine("=======TABLE OF GIVEN NUMBER USING FOR LOOP======\n");

            Console.WriteLine("Enter the number:");

            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("{0}*{1}={2}", num, i, i * num);
            }
            Console.ReadLine();
        }
    }
}
