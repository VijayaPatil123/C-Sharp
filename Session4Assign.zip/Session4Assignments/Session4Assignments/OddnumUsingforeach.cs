﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignments
{
    class OddnumUsingforeach
    {
        static void Main()
        {
            Console.WriteLine("===Odd Numbers from Given  Array===\n");

            int[] array1 = {11,24,35,36,33,26,12,27,29,28,2,6,8,5,7,13 };

                foreach (int a in array1)
                  {
                    Console.Write(a);
                 }
            
                foreach (int item in array1)
                {
                    if (item % 2 != 0)
                    {
                        Console.WriteLine(item);
                    }
                }

            

            Console.ReadLine();
        }
    }
}
