﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignments
{
    class EvenNumusingforeach
    {/// <summary>
    /// 
    /// </summary>
        static void Main()
        {  
            Console.WriteLine("===Even Numbers from Array Using Foreach====\n");

            int[] array1 = { 11, 24, 35, 36, 33, 26, 12, 27, 29, 28, 2, 6, 8, 5, 7, 13 };

            foreach (int temp in array1)
            {
                Console.Write(" {0} ",temp);
            }

            foreach (int item in array1)
            {
                if (item % 2 == 0)
                {
                   
                    Console.WriteLine(item);
                }
            }
            Console.ReadLine();
        }
    }
    }

