﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerDemo
{
    //CREATE SEALED CLASS PEN AND ADD STARTWRITING() AND STOPWRITING() FUNCTION
  sealed  class PenSealedClass
    {
        public string StartWriting()
        {
            return "StartWritng Method....\n\n";
        }
        public string StopWriting()
        {
            return "StopWriting Method....";
        }
    }

    class Pen
    {
        static void Main()
        {
            Console.WriteLine("=====Pen Program Using Sealed Class =====\n\n");

            PenSealedClass pen = new PenSealedClass();
           Console.WriteLine( pen.StartWriting());
            Console.WriteLine(pen.StopWriting());
            Console.ReadLine();
        }
    }
}
