﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerDemo
{
    class BankRequirement
    {

    }

    public interface Bank
    {
        void Deposit(double amount);
        void WithDraw(double amount);
    }

    class SavingAccount : Bank
    {
        double BalInAcc = 12000;
        void Bank.Deposit(double amount)
        {
            BalInAcc = BalInAcc + amount;
            Console.WriteLine("After Deposite amount is Added {0}", amount);
        }

        void Bank.WithDraw(double amount)
        {
            if (BalInAcc > amount)
            {
                Console.WriteLine("Amount in your Account {0}", BalInAcc);
                BalInAcc = BalInAcc - amount;
                Console.WriteLine("After Withdraw amount is {0}", BalInAcc);
            }

            else
            {
                Console.WriteLine("Balance is Low....");
            }
        }

        
    }
    class CurrentAccount : Bank
    {
        double BalInAcc = 52000;
        void Bank.Deposit(double amount)
        {
            BalInAcc = BalInAcc + amount;
            Console.WriteLine("After Withdraw amount is  {0}", amount);
        }

        void Bank.WithDraw(double amount)
        {
            if (BalInAcc > amount)
            {
                Console.WriteLine("Amount in your Account {0}", BalInAcc);
                BalInAcc = BalInAcc - amount;
                Console.WriteLine("After Withdraw amount is {0}", BalInAcc);
            }

            else
            {
                Console.WriteLine(" Account balance Low...");
            }
        }
    }


    class MainB : SavingAccount, Bank
    {

        static void Main()
        {
            Console.WriteLine("=======Bank-Requirement:=======\n");
            Console.WriteLine("Enter your Choice \n 1:Saving Account \n 2:Current Account\n\n");
            int ch = Convert.ToInt32(Console.ReadLine());

            Bank bank1 = new SavingAccount();

            Bank bank2 = new CurrentAccount();

            switch (ch)
            {
                case 1:
                    Console.WriteLine("Choose  Operation \n 1:Deposit \n 2:Withdrow");
                    int ch1 = Convert.ToInt32(Console.ReadLine());

                    switch (ch1)

                    {
                        case 1: Console.WriteLine("Enter  Amount to be Deposite:\n\n");
                            double amount = Convert.ToDouble(Console.ReadLine());
                            bank1.Deposit(amount);
                            break;
                        case 2: Console.WriteLine("Enter The Amount to be Withdraw:\n\n");

                            double amount1 = Convert.ToDouble(Console.ReadLine());
                            bank1.WithDraw(amount1);
                            break;
                        default:Console.WriteLine("Invalid Choice...");
                            break;
                    }
                    break;

                case 2:
                    Console.WriteLine("Choose  Operation \n 1:Deposite \n 2:Withdraw");
                    int ch2 = Convert.ToInt32(Console.ReadLine());

                    switch(ch2)
                    {
                        case 1:Console.WriteLine("Enter  Amount to  Deposite:");
                            double amount = Convert.ToDouble(Console.ReadLine());
                            bank2.Deposit(amount);
                            break;

                        case 2:Console.WriteLine("Enter amount to Withdraw:");
                            double amount1 = Convert.ToDouble(Console.ReadLine());
                            bank2.WithDraw(amount1);
                            break;
                        default:Console.WriteLine("Invalid Choice...");
                            break;

                    }

                    break;

                default:Console.WriteLine("Invalid Input...");
                    break;

            }
            Console.ReadLine();
            
        }
    } 
}
