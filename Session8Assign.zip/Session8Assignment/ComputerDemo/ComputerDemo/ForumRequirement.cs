﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerDemo
{
    class ForumRequirement
    {
        static void Main()
        {
            Console.WriteLine("*****Forum-Requirement*****\n\n");

            Console.WriteLine("Enter Your ID:");
            long Id = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("Enter Your Name:");
            string Name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter Your EmailID:");
            string EmailIdId = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter Your DateOf Birth:");
            string DateOfBirth = Convert.ToString(Console.ReadLine());


            User u = new User();
            User u1 = new User(Id,Name,EmailIdId,DateOfBirth);
            Console.WriteLine(u1.ToString());
            Console.ReadLine();



        }
    
    }

    class User
    {
        private long Id;
        private string Name;
        private string Emailid;
        private string DateOfBirth;


        //public long UId { get; set; }

        //public string UName { get; set; }

        //public string UEmailid { get; set; }

        //public string UDateOfBirth { get; set; }


        public User()
        {
            Console.WriteLine("Default Constructor Of User....");
        }

        public User(long UserId,string Name,string Emailid,string DateOfBirth)
        {
            this.Id = UserId;
            this.Name = Name;
            this.Emailid = Emailid;
            this.DateOfBirth = DateOfBirth;
        }

        public override string ToString()
        {
            return string.Format("\n UserID ={0} \n UserName={1}\n UserEmailID={2} \n DateOfBirth={3}", Id, Name, Emailid, DateOfBirth);
        }

    }
}
