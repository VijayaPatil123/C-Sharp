﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerDemo
{
    //CREATE ABSTRACT CLASS COMPUTER HAVING BOOTUP() AND SHUTDOWN() FUNCTION.
    abstract class Computer
    {
        public abstract string BootUp();

       
        
        public abstract string ShutDown();

       
       
    }
    class SuperComputer : Computer
    {
        public override string BootUp()
        {
            return "System is Booted from SuperComputer";
        }

        public override string ShutDown()
        {
            return "system is Shut Down  from SuperComputer\n\n";
        }
    }
    class MainFraim : Computer
    {
        public override string BootUp()
        {
            return "System is Booted from MainFraimComputr";
        }

        public override string ShutDown()
        {
            return "system is Shut Down from MainFraimComputr\n\n";
        }
    }
    class MicroComputer : Computer
    {
        public override string BootUp()
        {
            return "System is Booted from MicroComputer";
        }

        public override string ShutDown()
        {
            return "system is Shut Down from MicroComputer\n\n";
        }
    }

    class Laptop
    {
        static void Main()
        {

            Console.WriteLine("=====Program For Computer=====\n\n");

            SuperComputer SC = new SuperComputer();
            Console.WriteLine(  SC.BootUp());
            Console.WriteLine(SC.ShutDown());

            MainFraim MF = new MainFraim();
            Console.WriteLine(MF.BootUp());
            Console.WriteLine(MF.ShutDown());

            MicroComputer MC = new MicroComputer();
            Console.WriteLine(MC.BootUp());
            Console.WriteLine(MC.ShutDown());

            Console.ReadLine();
        }
    }
}
