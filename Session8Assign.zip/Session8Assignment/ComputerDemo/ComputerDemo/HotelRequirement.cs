﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerDemo
{
    class HotelRequirement
    {
        //Hote Requirement using constructor and override tostring()
        static void Main()
        {
            Console.WriteLine("=====HOTEL DETAILS:======\n\n");

            Console.WriteLine("Enter Number:");
            int Number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please Enter Floor:");
            int Floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please Enter Type:");
            string Type = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Please Enter Capacity:");
            int Capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please Enter BookedDateTime:");
            DateTime BookedTime = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Please Enter Price:");
            double Price = Convert.ToDouble(Console.ReadLine());

            Room r = new Room();
           
            Room r1 = new Room(Number,Floor,Type,Capacity,BookedTime,Price);
            Console.WriteLine(r1.ToString());
            Console.ReadLine();


        }

    }
    class Room
    {
        private int Number;
        private int Floor;
        private string Type;
        private int Capacity;
        private DateTime BookedTime;
        private double Price;

        public Room()
        {
            Console.WriteLine("Default Constructor Of Class Room.....");
        }

        public Room(int Number, int Floor, string Type, int Capacity, DateTime BookedTime, double Price)
        {
            this.Number = Number;
            this.Floor = Floor;
            this.Type = Type;
            this.Capacity=Capacity;
            this.BookedTime=BookedTime;
            this.Price = Price;

        }

        public int Number1 { get; set; }
        public int Floor1 { get; set; }
        public string Type1 { get; set; }
        public int Capacity1 { get; set; }
        public DateTime BookedTime1 { get; set; }
        public double Price1 { get; set; }



        public override string ToString()
        {
            return string.Format("Number={0} \n Floor={1} \n Type={2} \n Capacity={3} \n BookedDate={4} \n Price={5}",Number,Floor,Type,Capacity,BookedTime,Price);
        }

    }

    
}
